package com.example.proyecto_actividad_24_11

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
