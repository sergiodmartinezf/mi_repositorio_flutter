# proyecto_actividad_24_11

La aplicación creada genera un botón el cual, al ser presionado, muestra un mensaje de "¡Hola Mundo!".
